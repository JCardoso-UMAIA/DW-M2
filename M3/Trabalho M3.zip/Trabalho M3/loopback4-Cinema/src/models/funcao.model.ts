import {Entity, model, property} from '@loopback/repository';

@model()
export class Funcao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;


  constructor(data?: Partial<Funcao>) {
    super(data);
  }
}

export interface FuncaoRelations {
  // describe navigational properties here
}

export type FuncaoWithRelations = Funcao & FuncaoRelations;
