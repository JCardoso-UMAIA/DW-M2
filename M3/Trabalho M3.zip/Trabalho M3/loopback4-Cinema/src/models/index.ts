export * from './pessoa.model';
export * from './filme.model';
export * from './filme-pais.model';
export * from './funcao.model';
export * from './papel.model';
export * from './bilheteira.model';
export * from './merchandising.model';
export * from './custo-producao.model';
