import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {
    idInjection: false,
    mysql: {schema: 'Cinema', table: 'Papel'},
    postgresql: {
      schema: 'Cinema',
      table: 'Papel'
    }
  }
})
export class Papel extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id: number; // Primary key

  @property({
    type: 'number',
    required: true,
    mysql: {
      columnName: 'funcao_id',
    },
  })
  funcao_id: number;

  @property({
    type: 'number',
    required: true,
    mysql: {
      columnName: 'pessoa_id',
    },
  })
  pessoa_id: number;

  @property({
    type: 'number',
    required: true,
    mysql: {
      columnName: 'filme_id',
    },
  })
  filme_id: number;

  constructor(data?: Partial<Papel>) {
    super(data);
  }
}

export interface PapelRelations {
  // describe navigational properties here
}

export type PapelWithRelations = Papel & PapelRelations;