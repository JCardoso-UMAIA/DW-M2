import {belongsTo, Entity, model, property,hasMany} from '@loopback/repository';
import {Pessoa} from './pessoa.model';
import {Papel} from './papel.model';
import {Bilheteira} from './bilheteira.model';


@model({settings: {strict: false}})
export class Filme extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true, // O id é gerado automaticamente
  })
  id?: number;  // O nome da chave primária é filme_id, com o sufixo "_id"

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @belongsTo(() => Pessoa, {keyFrom: 'realizador_id', keyTo: 'id'}) // Relacionamento com Pessoa
  realizador_id: number;

  @property({
    type: 'string',
    required: true,
  })
  genero: string;

  @property({
    type: 'string',
    required: true,
  })
  ano: string;

  @property({
    type: 'string',
    required: true,
  })
  pais: string;

  @hasMany(() => Papel, {keyTo: 'filme_id'})
  papeis: Papel[];

  @hasMany(() => Bilheteira, {keyTo: 'filme_id'})
  bilheteiras: Bilheteira[];

  // Define outras propriedades ou métodos se necessário

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Filme>) {
    super(data);
  }
}

export interface FilmeRelations {
  // Descreva as propriedades de navegação, caso existam
}

export type FilmeWithRelations = Filme & FilmeRelations;
