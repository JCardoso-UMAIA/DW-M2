import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Filme} from './filme.model';

@model()
export class Merchandising extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id: number; // Primary key

  @property({
    type: 'number',
    required: true,
  })
  filme_id: number;

  @property({
    type: 'number',
    required: true,
  })
  merchandising: number;

  constructor(data?: Partial<Merchandising>) {
    super(data);
  }
}

export interface MerchandisingRelations {
  // describe navigational properties here
}

export type MerchandisingWithRelations = Merchandising & MerchandisingRelations;