import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Filme} from './filme.model';

@model()
export class Bilheteira extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id: number; // Primary key

  @property({
    type: 'string',
    required: true,
  })
  pais_exibicao: string;

  @property({
    type: 'number',
    required: true,
  })
  receita_bilheteira: number;

  @belongsTo(() => Filme, {keyFrom: 'filme_id', keyTo: 'id'})
  filme_id: number;

  constructor(data?: Partial<Bilheteira>) {
    super(data);
  }
}

export interface BilheteiraRelations {
  // describe navigational properties here
}

export type BilheteiraWithRelations = Bilheteira & BilheteiraRelations;