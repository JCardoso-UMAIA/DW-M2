import {Entity, model, property,hasMany} from '@loopback/repository';
import {Filme} from './filme.model';

@model()
export class Pessoa extends Entity {
  
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  nome: string;

  @property({
    type: 'string',
    required: true,
  })
  nome_artistico: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      format: 'date' // Espera somente "YYYY-MM-DD"
    },
  })
  data_nascimento: string;

  @property({
    type: 'string',
    required: true,
  })
  local_nascimento: string | null;

  @property({
    type: 'date', // Modificado para 'date' para refletir o formato de data
    required: false, // Campo opcional, já que a pessoa pode estar viva
    jsonSchema: {
      nullable: true,
    },
  })
  data_morte?: string | null; // Pode ser nulo se a pessoa não morreu

  @property({
    type: 'string',
    required: false, // Pode ser nulo se a pessoa não morreu
  })
  local_morte?: string | null;

  // Relacionamento com Filme (um para muitos)
  @hasMany(() => Filme, {keyTo: 'realizador_id'})
  filmes: Filme[];

  [prop: string]: any;

  constructor(data?: Partial<Pessoa>) {
    super(data);
  }
}

export interface PessoaRelations {
  // Relacionamentos adicionais podem ser descritos aqui, se houver
}

export type PessoaWithRelations = Pessoa & PessoaRelations;
