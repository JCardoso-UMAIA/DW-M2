import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {
    // Explicitamente especificar o nome da tabela para corresponder ao banco de dados
    mysql: {
      table: 'Filme_Pais'
    }
  }
})
export class FilmePais extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id: number; // Primary key

  @property({
    type: 'number',
    required: true,
  })
  filme_id: number;

  @property({
    type: 'string',
    required: true,
  })
  pais: string;

  constructor(data?: Partial<FilmePais>) {
    super(data);
  }
}

export interface FilmePaisRelations {
  // descreva propriedades de navegação aqui
}

export type FilmePaisWithRelations = FilmePais & FilmePaisRelations;