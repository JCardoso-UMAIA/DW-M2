import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Filme} from './filme.model';

@model({
  settings: {
    foreignKeys: {
      fk_custo_producao_filme: {
        name: 'fk_custo_producao_filme',
        entity: 'Filme',
        entityKey: 'filme_id',  // Nome da chave primária no modelo Filme
        foreignKey: 'filme_id',  // Nome da chave estrangeira no modelo CustoProducao
      },
    },
  },
})
export class Custo_Producao extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id: number; // Primary key

  @property({
    type: 'number',
    required: true,
  })
  filme_id: number; // Chave estrangeira no modelo

  @property({
    type: 'number',
    required: true,
  })
  custo_producao: number;

  constructor(data?: Partial<Custo_Producao>) {
    super(data);
  }
}

export interface CustoProducaoRelations {
  filme?: Filme;
}

export type CustoProducaoWithRelations = Custo_Producao & CustoProducaoRelations;