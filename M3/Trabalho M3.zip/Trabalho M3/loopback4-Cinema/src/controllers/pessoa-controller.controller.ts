import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response, 
} 
from '@loopback/rest';
import {Pessoa} from '../models';
import {PessoaRepository} from '../repositories';

export class PessoaControllerController {
  constructor(
    @repository(PessoaRepository)
    public pessoaRepository : PessoaRepository,
  ) {}

  @post('/pessoas')
  @response(200, {
    description: 'Pessoa model instance',
    content: {'application/json': {schema: getModelSchemaRef(Pessoa)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Pessoa, {
            title: 'NewPessoa',
            exclude: ['id'],
          }),
        },
      },
    })
    pessoa: Omit<Pessoa, 'id'>,
  ): Promise<Pessoa> {
    return this.pessoaRepository.create(pessoa);
  }

  @get('/pessoas/count')
  @response(200, {
    description: 'Pessoa model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Pessoa) where?: Where<Pessoa>,
  ): Promise<Count> {
    return this.pessoaRepository.count(where);
  }

  @get('/pessoas')
  @response(200, {
    description: 'Array of Pessoa model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Pessoa, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Pessoa) filter?: Filter<Pessoa>,
  ): Promise<Pessoa[]> {
    return this.pessoaRepository.find(filter);
  }

  @get('/pessoas/{id}')
  @response(200, {
    description: 'Pessoa model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Pessoa, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Pessoa, {exclude: 'where'}) filter?: FilterExcludingWhere<Pessoa>
  ): Promise<Pessoa> {
    return this.pessoaRepository.findById(id, filter);
  }

  @put('/pessoas/{id}')
  @response(204, {
    description: 'Pessoa PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() pessoa: Pessoa,
  ): Promise<void> {
    await this.pessoaRepository.replaceById(id, pessoa);
  }

}
