import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response,
  patch,
} from '@loopback/rest';
import {Merchandising} from '../models';
import {MerchandisingRepository} from '../repositories';

export class MerchandisingControllerController {
  constructor(
    @repository(MerchandisingRepository)
    public merchandisingRepository : MerchandisingRepository,
  ) {}

  @get('/merchandisings/count')
  @response(200, {
    description: 'Merchandising model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Merchandising) where?: Where<Merchandising>,
  ): Promise<Count> {
    return this.merchandisingRepository.count(where);
  }

  @patch('/merchandisings/{filme_id}')
  @response(204, {
    description: 'Merchandising PATCH success',
  })
  async updateById(
    @param.path.number('filme_id') filme_id: number,
    @requestBody() merchandising: Partial<Merchandising>,
  ): Promise<void> {
    await this.merchandisingRepository.updateById(filme_id, merchandising);
  }

  @get('/merchandisings')
  @response(200, {
    description: 'Array of Merchandising model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Merchandising, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Merchandising) filter?: Filter<Merchandising>,
  ): Promise<Merchandising[]> {
    return this.merchandisingRepository.find(filter);
  }

  @get('/merchandisings/{filme_id}')
  @response(200, {
    description: 'Merchandising model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Merchandising, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('filme_id') filme_id: number,
    @param.filter(Merchandising, {exclude: 'where'}) filter?: FilterExcludingWhere<Merchandising>
  ): Promise<Merchandising> {
    return this.merchandisingRepository.findById(filme_id, filter);
  }

  @put('/merchandisings/{filme_id}')
  @response(204, {
    description: 'Merchandising PUT success',
  })
  async replaceById(
    @param.path.number('filme_id') filme_id: number,
    @requestBody() merchandising: Merchandising,
  ): Promise<void> {
    await this.merchandisingRepository.replaceById(filme_id, merchandising);
  }
}
