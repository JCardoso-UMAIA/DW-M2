import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {FilmePais} from '../models';
import {FilmePaisRepository} from '../repositories';

export class FilmePaisControllerController {
  constructor(
    @repository(FilmePaisRepository)
    public filmePaisRepository : FilmePaisRepository,
  ) {}

  @get('/Filme_Pais/count')
  @response(200, {
    description: 'Filme_Pais model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(FilmePais) where?: Where<FilmePais>,
  ): Promise<Count> {
    return this.filmePaisRepository.count(where);
  }

  @get('/Filme_Pais')
@response(200, {
  description: 'Array of FilmePais model instances',
  content: {
    'application/json': {
      schema: {
        type: 'array',
        items: getModelSchemaRef(FilmePais, {includeRelations: true}),
      },
    },
  },
})
async find(
  @param.filter(FilmePais) filter?: Filter<FilmePais>,
): Promise<FilmePais[]> {
  return this.filmePaisRepository.find(filter);
}

@get('/Filme_Pais/{filme_id}/{pais}')
@response(200, {
  description: 'Filme_Pais model instance',
  content: {
    'application/json': {
      schema: getModelSchemaRef(FilmePais, {includeRelations: true}),
    },
  },
})
async findById(
  @param.path.number('filme_id') filmeId: number,
  @param.path.string('pais') pais: string,
  @param.filter(FilmePais, {exclude: 'where'}) filter?: FilterExcludingWhere<FilmePais>
): Promise<FilmePais | null> {  // Retorna um único objeto ou null
  const filtro: Filter<FilmePais> = {
    where: {
      filme_id: filmeId,
      pais: pais,
    },
  };

  return this.filmePaisRepository.findOne(filtro);
}

  @put('/filme-pais/{id}')
  @response(204, {
    description: 'FilmePais PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() filmePais: FilmePais,
  ): Promise<void> {
    await this.filmePaisRepository.replaceById(id, filmePais);
  }

}
