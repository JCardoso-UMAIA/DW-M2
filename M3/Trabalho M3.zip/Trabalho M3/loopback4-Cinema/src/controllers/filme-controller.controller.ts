import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Filme} from '../models';
import {FilmeRepository} from '../repositories';

export class FilmeControllerController {
  constructor(
    @repository(FilmeRepository)
    public filmeRepository : FilmeRepository,
  ) {}


  @get('/filmes/count')
  @response(200, {
    description: 'Filme model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Filme) where?: Where<Filme>,
  ): Promise<Count> {
    return this.filmeRepository.count(where);
  }

  @get('/filmes')
  @response(200, {
    description: 'Array of Filme model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Filme, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Filme) filter?: Filter<Filme>,
  ): Promise<Filme[]> {
    return this.filmeRepository.find(filter);
  }

  @get('/filmes/{id}')
  @response(200, {
    description: 'Filme model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Filme, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Filme, {exclude: 'where'}) filter?: FilterExcludingWhere<Filme>
  ): Promise<Filme> {
    return this.filmeRepository.findById(id, filter);
  }

  @del('/filmes/{id}')
@response(204, {
  description: 'Filme DELETE success',
})
async deleteById(@param.path.number('id') id: number): Promise<void> {
await this.filmeRepository.dataSource.execute('DELETE FROM Bilheteira WHERE filme_id = ?', [id]);
await this.filmeRepository.dataSource.execute('DELETE FROM Custo_Producao WHERE filme_id = ?', [id]);
await this.filmeRepository.dataSource.execute('DELETE FROM Filme_Pais WHERE filme_id = ?', [id]);
await this.filmeRepository.dataSource.execute('DELETE FROM Merchandising WHERE filme_id = ?', [id]);
await this.filmeRepository.dataSource.execute('DELETE FROM Papel WHERE filme_id = ?', [id]);
await this.filmeRepository.deleteById(id);
}
}
