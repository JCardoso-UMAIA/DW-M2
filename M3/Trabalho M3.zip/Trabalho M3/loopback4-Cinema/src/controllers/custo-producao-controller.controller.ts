import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response,
  patch,
} from '@loopback/rest';
import {Custo_Producao} from '../models';
import {CustoProducaoRepository} from '../repositories';

export class CustoProducaoController {
  constructor(
    @repository(CustoProducaoRepository)
    public custoProducaoRepository: CustoProducaoRepository,
  ) {}

  @get('/Custo_Producao/count') // Rota com nome correto de tabela
  @response(200, {
    description: 'Custo_Producao model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Custo_Producao) where?: Where<Custo_Producao>,
  ): Promise<Count> {
    return this.custoProducaoRepository.count(where);
  }

  @get('/Custo_Producao') // Rota com nome correto de tabela
  @response(200, {
    description: 'Array of CustoProducao model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Custo_Producao, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Custo_Producao) filter?: Filter<Custo_Producao>,
  ): Promise<Custo_Producao[]> {
    return this.custoProducaoRepository.find(filter);
  }

  @get('/Custo_Producao/{filme_id}') // Rota com nome correto de tabela
  @response(200, {
    description: 'CustoProducao model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Custo_Producao, {includeRelations: true}),
      },
    },
  })
  async findByFilmeId(
    @param.path.number('filme_id') filmeId: number,
  ): Promise<Custo_Producao[]> {
    return this.custoProducaoRepository.find({
      where: {filme_id: filmeId},
    });
  }

  @put('/Custo_Producao/{filme_id}') // Rota com nome correto de tabela
  @response(204, {
    description: 'CustoProducao PUT success',
  })
  async replaceById(
    @param.path.number('filme_id') filmeId: number,
    @requestBody() custoProducao: Custo_Producao,
  ): Promise<void> {
    await this.custoProducaoRepository.replaceById(filmeId, custoProducao);
  }


}
