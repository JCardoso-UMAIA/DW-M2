import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response,
  patch,
} from '@loopback/rest';
import {Papel} from '../models';
import {PapelRepository} from '../repositories';
export class PapelControllerController {
  constructor(
    @repository(PapelRepository)
    public papelRepository : PapelRepository,
  ) {}
  @get('/papels/count')
  @response(200, {
    description: 'Papel model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Papel) where?: Where<Papel>,
  ): Promise<Count> {
    return this.papelRepository.count(where);
  }
  @get('/papels')
  @response(200, {
    description: 'Array of Papel model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Papel, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Papel) filter?: Filter<Papel>,
  ): Promise<Papel[]> {
    return this.papelRepository.find(filter);
  }
  @get('/papels/{id}')
  @response(200, {
    description: 'Papel model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Papel, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') funcao_id: number,
    @param.filter(Papel, {exclude: 'where'}) filter?: FilterExcludingWhere<Papel>
  ): Promise<Papel> {
    return this.papelRepository.findById(funcao_id, filter);
  }
  @put('/papels/{id}')
  @response(204, {
    description: 'Papel PUT success',
  })
  async replaceById(
    @param.path.number('id') funcao_id: number,
    @requestBody() papel: Papel,
  ): Promise<void> {
    await this.papelRepository.replaceById(funcao_id, papel);
  }

  @patch('/papels/{id}')
  @response(204, {
    description: 'Papel PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody() papel: Partial<Papel>,
  ): Promise<void> {
    await this.papelRepository.updateById(id, papel);
  }
}