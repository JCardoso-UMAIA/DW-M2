import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  put,
  del,
  requestBody,
  response,
  patch,
} from '@loopback/rest';
import {Funcao} from '../models';
import {FuncaoRepository,FilmeRepository} from '../repositories';


export class FuncaoControllerController {
  constructor(
    @repository(FuncaoRepository)
    public funcaoRepository : FuncaoRepository,
    @repository(FilmeRepository)
    public filmeRepository : FilmeRepository,
  ) {}

  @post('/funcaos')
  @response(200, {
    description: 'Funcao model instance',
    content: {'application/json': {schema: getModelSchemaRef(Funcao)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Funcao, {
            title: 'NewFuncao',
            exclude: ['id'],
          }),
        },
      },
    })
    funcao: Omit<Funcao, 'id'>,
  ): Promise<Funcao> {
    return this.funcaoRepository.create(funcao);
  }

  @get('/funcaos/count')
  @response(200, {
    description: 'Funcao model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Funcao) where?: Where<Funcao>,
  ): Promise<Count> {
    return this.funcaoRepository.count(where);
  }

  @get('/funcaos')
  @response(200, {
    description: 'Array of Funcao model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Funcao, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Funcao) filter?: Filter<Funcao>,
  ): Promise<Funcao[]> {
    return this.funcaoRepository.find(filter);
  }

  @get('/funcaos/{id}')
  @response(200, {
    description: 'Funcao model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Funcao, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Funcao, {exclude: 'where'}) filter?: FilterExcludingWhere<Funcao>
  ): Promise<Funcao> {
    return this.funcaoRepository.findById(id, filter);
  }

  @put('/funcaos/{id}')
  @response(204, {
    description: 'Funcao PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() funcao: Funcao,
  ): Promise<void> {
    await this.funcaoRepository.replaceById(id, funcao);
  }

  @del('/funcaos/{id}')
  @response(204, {
    description: 'Funcao DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    // Exclua os registros na tabela Papel que estão relacionados à função
    await this.funcaoRepository.dataSource.execute('DELETE FROM Papel WHERE funcao_id = ?', [id]);
    
    // Agora exclua a função
    await this.funcaoRepository.deleteById(id);
  }
  @patch('/funcaos/{id}')
  @response(204, {
    description: 'Funcao PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody() funcao: Partial<Funcao>,
  ): Promise<void> {
    await this.funcaoRepository.updateById(id, funcao);
  }

}
