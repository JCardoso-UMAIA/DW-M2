import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
  put,
  requestBody,
  response,
} from '@loopback/rest';
import {Bilheteira} from '../models';
import {BilheteiraRepository} from '../repositories';

export class BilheteiraControllerController {
  constructor(
    @repository(BilheteiraRepository)
    public bilheteiraRepository : BilheteiraRepository,
  ) {}

  @get('/bilheteiras/count')
  @response(200, {
    description: 'Bilheteira model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Bilheteira) where?: Where<Bilheteira>,
  ): Promise<Count> {
    return this.bilheteiraRepository.count(where);
  }

  @get('/bilheteiras')
  @response(200, {
    description: 'Array of Bilheteira model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Bilheteira, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Bilheteira) filter?: Filter<Bilheteira>,
  ): Promise<Bilheteira[]> {
    return this.bilheteiraRepository.find(filter);
  }

  @get('/bilheteiras/{filme_id}')
  @response(200, {
  description: 'Bilheteira model instance',
  content: {'application/json': {schema: getModelSchemaRef(Bilheteira)}},
})
async findByFilmeId(
  @param.path.number('filme_id') filmeId: number,
): Promise<Bilheteira[]> {
  return this.bilheteiraRepository.find({where: {filme_id: filmeId}});
}
}
