import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Pessoa, PessoaRelations} from '../models';

export class PessoaRepository extends DefaultCrudRepository<
  Pessoa,
  typeof Pessoa.prototype.id,
  PessoaRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Pessoa, dataSource);
  }
}
