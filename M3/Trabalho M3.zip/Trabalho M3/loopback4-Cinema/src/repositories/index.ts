export * from './pessoa.repository';
export * from './filme.repository';
export * from './funcao.repository';
export * from './filme-pais.repository';
export * from './papel.repository';
export * from './bilheteira.repository';
export * from './custo-producao.repository';
export * from './merchandising.repository';
