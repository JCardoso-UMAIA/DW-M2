import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Bilheteira, BilheteiraRelations} from '../models';

export class BilheteiraRepository extends DefaultCrudRepository<
  Bilheteira,
  typeof Bilheteira.prototype.pais_exibicao,
  BilheteiraRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Bilheteira, dataSource);
  }
}
