import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Papel, PapelRelations} from '../models';
export class PapelRepository extends DefaultCrudRepository<
  Papel,
  typeof Papel.prototype.funcao_id,
  PapelRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Papel, dataSource);
  }
}
