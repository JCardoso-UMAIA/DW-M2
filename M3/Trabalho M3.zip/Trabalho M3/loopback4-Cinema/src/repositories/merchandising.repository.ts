import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Merchandising, MerchandisingRelations} from '../models';

export class MerchandisingRepository extends DefaultCrudRepository<
  Merchandising,
  typeof Merchandising.prototype.filme_id,
  MerchandisingRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Merchandising, dataSource);
  }
}
