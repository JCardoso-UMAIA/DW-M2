import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Custo_Producao, CustoProducaoRelations} from '../models';

export class CustoProducaoRepository extends DefaultCrudRepository<
  Custo_Producao,
  typeof Custo_Producao.prototype.filme_id,
  CustoProducaoRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Custo_Producao, dataSource);
  }
}
