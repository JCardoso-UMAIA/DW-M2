import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {FilmePais, FilmePaisRelations} from '../models';
export class FilmePaisRepository extends DefaultCrudRepository<
  FilmePais,
  typeof FilmePais.prototype.filme_id,
  FilmePaisRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(FilmePais, dataSource);
  }
}
