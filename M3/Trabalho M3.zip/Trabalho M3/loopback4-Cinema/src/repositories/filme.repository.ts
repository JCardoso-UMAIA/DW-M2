import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Filme, FilmeRelations} from '../models';

export class FilmeRepository extends DefaultCrudRepository<
  Filme,
  typeof Filme.prototype.Filme_id,
  FilmeRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Filme, dataSource);
  }
}
