import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {CinemaDataSource} from '../datasources';
import {Funcao, FuncaoRelations} from '../models';

export class FuncaoRepository extends DefaultCrudRepository<
  Funcao,
  typeof Funcao.prototype.id,
  FuncaoRelations
> {
  constructor(
    @inject('datasources.Cinema') dataSource: CinemaDataSource,
  ) {
    super(Funcao, dataSource);
  }
}
