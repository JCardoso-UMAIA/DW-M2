import {inject, lifeCycleObserver, LifeCycleObserver} from '@loopback/core';
import {juggler} from '@loopback/repository';

const config = {
  name: 'Cinema',
  connector: 'mysql',
  url: '',
  host: 'database',
  port: 3306,
  user: 'root',
  password: '12345678',
  database: 'Cinema'
};

@lifeCycleObserver('datasource')
export class CinemaDataSource extends juggler.DataSource
  implements LifeCycleObserver {
  static dataSourceName = 'Cinema';
  static readonly defaultConfig = config;

  constructor(
    @inject('datasources.config.Cinema', {optional: true})
    dsConfig: object = config,
  ) {
    super(dsConfig);
  }
}
export default CinemaDataSource;
