DROP DATABASE IF EXISTS `Cinema`;
CREATE DATABASE `Cinema`;

USE `Cinema`;

CREATE TABLE Pessoa (
    id int AUTO_INCREMENT PRIMARY KEY,  
    nome varchar(30) NOT NULL,
    nome_artistico varchar(50) NOT NULL,
    data_nascimento date NOT NULL,
    local_nascimento varchar(50) NOT NULL,
    data_morte date,
    local_morte VARCHAR(50)
);

CREATE TABLE Filme (
    id int AUTO_INCREMENT PRIMARY KEY,
    nome varchar(50),
    realizador_id int NOT NULL,
    genero varchar(50),
    ano date,
    pais varchar(50),
    FOREIGN KEY (realizador_id) REFERENCES Pessoa(id)
);

CREATE TABLE Filme_Pais (
    id int AUTO_INCREMENT PRIMARY KEY,
    filme_id int,
    pais VARCHAR(50),
    FOREIGN KEY (filme_id) REFERENCES Filme(id)
);

CREATE TABLE Funcao (
    id int AUTO_INCREMENT PRIMARY KEY,
    nome varchar(50) NOT NULL
);

CREATE TABLE Papel (
    id int AUTO_INCREMENT PRIMARY KEY,
    funcao_id int,
    pessoa_id int,
    filme_id int,
    FOREIGN KEY (funcao_id) REFERENCES Funcao(id),
    FOREIGN KEY (pessoa_id) REFERENCES Pessoa(id),
    FOREIGN KEY (filme_id) REFERENCES Filme(id)
);

CREATE TABLE Bilheteira (
    id int AUTO_INCREMENT PRIMARY KEY,
    filme_id int,
    pais_exibicao VARCHAR(255) NOT NULL,
    receita_bilheteira FLOAT NOT NULL,
    FOREIGN KEY (filme_id) REFERENCES Filme(id)
);

CREATE TABLE Merchandising (
    id int AUTO_INCREMENT PRIMARY KEY,
    filme_id int,
    merchandising FLOAT NOT NULL,
    FOREIGN KEY (filme_id) REFERENCES Filme(id)
);

CREATE TABLE Custo_Producao (
    id int AUTO_INCREMENT PRIMARY KEY,
    filme_id int,
    custo_producao FLOAT NOT NULL,
    FOREIGN KEY (filme_id) REFERENCES Filme(id)
);

INSERT INTO Pessoa (id, nome, nome_artistico, data_nascimento, local_nascimento, data_morte, local_morte)
VALUES
(1, 'Steven Allan Spielberg', 'Steven Spielberg', '1946-12-18', 'Cincinnati, Ohio, USA', NULL, NULL),
(2, 'Christopher Edward Nolan', 'Christopher Nolan', '1970-07-30', 'London, England, UK', NULL, NULL),
(3, 'Leonardo Wilhelm DiCaprio', 'Leonardo DiCaprio', '1974-11-11', 'Los Angeles, California, USA', NULL, NULL),
(4, 'Kathrin Romary Beckinsale', 'Kate Beckinsale', '1973-07-26', 'London, England, UK', NULL, NULL),
(5, 'Timothy Walter Burton', 'Tim Burton', '1958-08-25', 'Burbank, California, USA', NULL, NULL),
(6, 'Margot Elise Robbie', 'Margot Robbie', '1990-07-02', 'Dalby, Queensland, Australia', NULL, NULL),
(7, 'Thomas Jeffrey Hanks', 'Tom Hanks', '1956-07-09', 'Concord, California, USA', NULL, NULL),
(8, 'Scarlett Ingrid Johansson', 'Scarlett Johansson', '1984-11-22', 'New York City, New York, USA', NULL, NULL),
(9, 'Keanu Charles Reeves', 'Keanu Reeves', '1964-09-02', 'Beirut, Lebanon', NULL, NULL),
(10, 'Anne Jacqueline Hathaway', 'Anne Hathaway', '1982-11-12', 'Brooklyn, New York, USA', NULL, NULL),
(11, 'James Francis Cameron', 'James Cameron', '1954-08-16', 'Kapuskasing, Ontario, Canada', NULL, NULL),
(12, 'Christian Charles Philip Bale', 'Christian Bale', '1974-01-30', 'Haverfordwest, Pembrokeshire, Wales, UK', NULL, NULL),
(13, 'Gal Gadot-Varsano', 'Gal Gadot', '1985-04-30', 'Petah Tikva, Israel', NULL, NULL),
(14, 'Bradley Charles Cooper', 'Bradley Cooper', '1975-01-05', 'Philadelphia, Pennsylvania, USA', NULL, NULL),
(15, 'Emma Charlotte Duerre Watson', 'Emma Watson', '1990-04-15', 'Paris, France', NULL, NULL),
(16, 'Jennifer Shrader Lawrence', 'Jennifer Lawrence', '1990-08-15', 'Indian Hills, Kentucky, USA', NULL, NULL),
(17, 'Matthew Paige Damon', 'Matt Damon', '1970-10-08', 'Cambridge, Massachusetts, USA', NULL, NULL),
(18, 'Benjamin G za Affleck', 'Ben Affleck', '1972-08-15', 'Berkeley, California, USA', NULL, NULL),
(19, 'Daniel Wroughton Craig', 'Daniel Craig', '1968-03-02', 'Chester, Cheshire, England, UK', NULL, NULL),
(20, 'Natalie Portman', 'Natalie Portman', '1981-06-09', 'Jerusalem, Israel', NULL, NULL),
(21, 'Alfred Joseph Hitchcock', 'Alfred Hitchcock', '1899-08-13', 'Leytonstone, London, England, UK', '1980-04-29', 'Bel Air, Los Angeles, California, USA'),
(22, 'Luis Bu uel Portol s', 'Luis Bu uel', '1900-02-22', 'Calanda, Teruel, Aragon, Spain', '1983-07-29', 'Mexico City, Mexico'),
(23, 'Fellini Federico', 'Federico Fellini', '1920-01-20', 'Rimini, Emilia-Romagna, Italy', '1993-10-31', 'Rome, Italy'),
(24, 'Manoel Oliveira', 'Manoel de Oliveira', '1908-12-11', 'Porto, Portugal', '2015-04-02', 'Porto, Portugal'),
(25, 'Jean-Luc Godard', 'Jean-Luc Godard', '1930-12-03', 'Paris, France', NULL, NULL),
(26, 'Agnes Varda', 'Agn s Varda', '1928-05-30', 'Ixelles, Belgium', '2019-03-29', 'Paris, France'),
(27, 'Joaquim Baptista de Almeida', 'Joaquim de Almeida', '1957-03-15', 'Lisbon, Portugal', NULL, NULL),
(28, 'Pedro Almod var Caballero', 'Pedro Almod var', '1949-09-25', 'Calzada de Calatrava, Ciudad Real, Spain', NULL, NULL),
(29, 'Pierre Niney', 'Pierre Niney', '1989-03-13', 'Boulogne-Billancourt, Hauts-de-Seine, France', NULL, NULL),
(30, 'Lea H l ne Clausonne', 'L a Seydoux', '1985-07-01', 'Paris, France', NULL, NULL),
(31, 'Antonio Banderas', 'Antonio Banderas', '1960-08-10', 'M laga, Andalusia, Spain', NULL, NULL),
(32, 'Marion Cotillard', 'Marion Cotillard', '1975-09-30', 'Paris, France', NULL, NULL),
(33, 'Ingrid Bergman', 'Ingrid Bergman', '1915-08-29', 'Stockholm, Sweden', '1982-08-29', 'London, England, UK'),
(34, 'Humphrey DeForest Bogart', 'Humphrey Bogart', '1899-12-25', 'New York City, New York, USA', '1957-01-14', 'Los Angeles, California, USA'),
(35, 'Vivien Leigh', 'Vivian Mary Hartley', '1913-11-05', 'Darjeeling, West Bengal, British India', '1967-07-08', 'Belgravia, London, England, UK'),
(36, 'Pedro Costa', 'Pedro Costa', '1959-03-03', 'Lisbon, Portugal', NULL, NULL),
(37, 'S nia Balac ', 'S nia Balac ', '1984-02-01', 'Portugal', NULL, NULL),
(38, 'Javier Bardem', 'Javier  ngel Encinas Bardem', '1969-03-01', 'Las Palmas de Gran Canaria, Spain', NULL, NULL),
(39, 'Audrey Justine Tautou', 'Audrey Tautou', '1976-08-09', 'Beaumont, Puy-de-D me, France', NULL, NULL),
(40, 'Daniel C sar Domingo', 'Daniel Br hl', '1978-06-16', 'Barcelona, Spain', NULL, NULL);

INSERT INTO Filme (id, nome, realizador_id, genero, ano, pais)
VALUES
(1, 'Jurassic Park', 1, 'Adventure, Sci-Fi', '1993-06-11', 'USA'),
(2, 'Inception', 2, 'Action, Sci-Fi', '2010-07-16', 'USA'),
(3, 'Titanic', 11, 'Drama, Romance', '1997-12-19', 'USA'),
(4, 'The Dark Knight', 2, 'Action, Crime', '2008-07-18', 'USA'),
(5, 'Avatar', 11, 'Action, Adventure', '2009-12-18', 'USA'),
(6, 'Wonder Woman', 13, 'Action, Adventure', '2017-06-02', 'USA'),
(7, 'The Matrix', 9, 'Action, Sci-Fi', '1999-03-31', 'USA'),
(8, 'Interstellar', 2, 'Adventure, Drama', '2014-11-07', 'USA'),
(9, 'Mad Max: Fury Road', 5, 'Action, Adventure', '2015-05-15', 'Australia'),
(10, 'The Revenant', 2, 'Adventure, Drama', '2015-12-25', 'USA'),
(11, 'Psycho', 21, 'Horror, Thriller', '1960-06-16', 'USA'),
(12, 'Viridiana', 22, 'Drama', '1961-05-17', 'Spain'),
(13, 'La Dolce Vita', 23, 'Comedy, Drama', '1960-02-05', 'Italy'),
(14, 'Aniki B b ', 24, 'Drama', '1942-12-18', 'Portugal'),
(15, '  bout de souffle', 25, 'Crime, Drama', '1960-03-16', 'France'),
(16, 'Cl o de 5   7', 26, 'Comedy, Drama', '1962-04-11', 'France'),
(17, 'Capit es de Abril', 24, 'Drama, History', '2000-04-21', 'Portugal'),
(18, 'La Belle  poque', 29, 'Comedy, Drama', '2019-11-06', 'France'),
(19, 'Pain and Glory', 28, 'Drama', '2019-03-22', 'Spain'),
(20, 'The Others', 31, 'Horror, Mystery', '2001-08-02', 'Spain'),
(21, 'The Lobster', 24, 'Comedy, Drama', '2015-05-15', 'Ireland'),
(22, 'Am lie', 39, 'Comedy, Romance', '2001-04-25', 'France'),
(23, 'Elite Squad', 36, 'Action, Crime', '2007-10-12', 'Brazil'),
(24, 'Biutiful', 38, 'Drama', '2010-10-04', 'Mexico'),
(25, 'Inglourious Basterds', 18, 'Adventure, Drama', '2009-08-21', 'USA'),
(26, 'Frances Ha', 40, 'Comedy, Drama', '2012-09-01', 'USA'),
(27, 'The Shape of Water', 7, 'Drama, Fantasy', '2017-12-01', 'USA'),
(28, 'Roma', 22, 'Drama', '2018-08-30', 'Mexico'),
(29, 'Frost/Nixon', 11, 'Biography, Drama', '2008-12-05', 'USA'),
(30, 'O Auto da Compadecida', 27, 'Comedy, Drama', '2000-09-15', 'Brazil');

INSERT INTO Filme_Pais (id, filme_id, pais)
VALUES
(1, 1, 'USA'),
(2, 1, 'Canada'),
(3, 2, 'USA'),
(4, 2, 'UK'),
(5, 3, 'USA'),
(6, 3, 'Canada'),
(7, 3, 'UK'),
(8, 4, 'USA'),
(9, 4, 'Canada'),
(10, 5, 'USA'),
(11, 5, 'UK'),
(12, 5, 'China'),
(13, 6, 'USA'),
(14, 6, 'Australia'),
(15, 7, 'USA'),
(16, 7, 'Canada'),
(17, 8, 'USA'),
(18, 8, 'UK'),
(19, 9, 'Australia'),
(20, 9, 'USA'),
(21, 10, 'USA'),
(22, 10, 'Canada'),
(23, 11, 'USA'),
(24, 12, 'Spain'),
(25, 13, 'Italy'),
(26, 14, 'Portugal'),
(27, 15, 'France'),
(28, 16, 'France'),
(29, 17, 'Portugal'),
(30, 18, 'France'),
(31, 19, 'Spain'),
(32, 20, 'Spain'),
(33, 21, 'Ireland'),
(34, 21, 'UK'),
(35, 22, 'France'),
(36, 23, 'Brazil'),
(37, 24, 'Mexico'),
(38, 25, 'USA'),
(39, 26, 'USA'),
(40, 27, 'USA'),
(41, 28, 'Mexico'),
(42, 29, 'USA'),
(43, 30, 'Brazil');

INSERT INTO Funcao (id, nome)
VALUES
(1, 'Ator'),
(2, 'Atriz'),
(3, 'Realizador'),
(4, 'Produtor'),
(5, 'Diretor de Fotografia'),
(6, 'Editor'),
(7, 'Compositor'),
(8, 'Desenhista de Produ  o'),
(9, 'Figurinista'),
(10, 'Roteirista'),
(11, 'Coordenador de Dubl s'),
(12, 'Diretor de Arte'),
(13, 'Assistente de Dire  o'),
(14, 'Operador de C mera'),
(15, 'T cnico de Som'),
(16, 'Assistente de Produ  o'),
(17, 'Core grafo'),
(18, 'Maquiador'),
(19, 'Assistente de Figurino'),
(20, 'Produtor Executivo'),
(21, 'Assistente de Elenco'),
(22, 'Produtor Associado'),
(23, 'Co-Produtor'),
(24, 'Diretor de Segunda Unidade');

INSERT INTO Papel (id, funcao_id, pessoa_id, filme_id)
VALUES
(1, 3, 1, 1), -- Steven Spielberg, Realizador de Jurassic Park
(2, 3, 2, 2), -- Christopher Nolan, Realizador de Inception
(3, 3, 11, 3), -- James Cameron, Realizador de Titanic
(4, 3, 2, 4), -- Christopher Nolan, Realizador de The Dark Knight
(5, 3, 11, 5), -- James Cameron, Realizador de Avatar
(6, 2, 13, 6), -- Gal Gadot, Atriz de Wonder Woman
(7, 1, 9, 7), -- Keanu Reeves, Ator de The Matrix
(8, 3, 2, 8), -- Christopher Nolan, Realizador de Interstellar
(9, 1, 12, 9), -- Christian Bale, Ator de Mad Max: Fury Road
(10, 1, 3, 10), -- Leonardo DiCaprio, Ator de The Revenant
(11, 2, 4, 1), -- Kate Beckinsale, Atriz em Jurassic Park
(12, 1, 3, 2), -- Leonardo DiCaprio, Ator em Inception
(13, 1, 3, 3), -- Leonardo DiCaprio, Ator em Titanic
(14, 1, 7, 4), -- Tom Hanks, Ator em The Dark Knight
(15, 2, 6, 5), -- Margot Robbie, Atriz em Avatar
(16, 1, 9, 6), -- Keanu Reeves, Ator em Wonder Woman
(17, 2, 10, 7), -- Anne Hathaway, Atriz em The Matrix
(18, 2, 8, 8), -- Scarlett Johansson, Atriz em Interstellar
(19, 2, 15, 9), -- Emma Watson, Atriz em Mad Max: Fury Road
(20, 2, 16, 10), -- Jennifer Lawrence, Atriz em The Revenant
(21, 3, 21, 11), -- Alfred Hitchcock, Realizador de Psycho
(22, 3, 22, 12), -- Luis Buñuel, Realizador de Viridiana
(23, 3, 23, 13), -- Federico Fellini, Realizador de La Dolce Vita
(24, 3, 24, 14), -- Manoel de Oliveira, Realizador de Aniki Bóbó
(25, 3, 25, 15), -- Jean-Luc Godard, Realizador de À bout de souffle
(26, 3, 26, 16), -- Agnès Varda, Realizador de Cléo de 5 à 7
(27, 3, 24, 17), -- Manoel de Oliveira, Realizador de Capitães de Abril
(28, 3, 29, 18), -- Pierre Niney, Realizador de La Belle Époque
(29, 3, 28, 19), -- Pedro Almodóvar, Realizador de Pain and Glory
(30, 3, 31, 20), -- Alejandro Amenábar, Realizador de The Others
(31, 3, 24, 21), -- Yorgos Lanthimos, Realizador de The Lobster
(32, 3, 39, 22), -- Jean-Pierre Jeunet, Realizador de Amélie
(33, 3, 36, 23), -- José Padilha, Realizador de Elite Squad
(34, 3, 38, 24), -- Alejandro González Iñárritu, Realizador de Biutiful
(35, 3, 18, 25), -- Quentin Tarantino, Realizador de Inglourious Basterds
(36, 3, 40, 26), -- Noah Baumbach, Realizador de Frances Ha
(37, 3, 7, 27), -- Guillermo del Toro, Realizador de The Shape of Water
(38, 3, 22, 28), -- Alfonso Cuarón, Realizador de Roma
(39, 3, 11, 29), -- Ron Howard, Realizador de Frost/Nixon
(40, 3, 27, 30), -- Guel Arraes, Realizador de O Auto da Compadecida
(41, 2, 30, 11), -- Léa Seydoux, Atriz em Psycho
(42, 1, 31, 12), -- Antonio Banderas, Ator em Viridiana
(43, 2, 32, 13), -- Marion Cotillard, Atriz em La Dolce Vita
(44, 1, 27, 14), -- Joaquim de Almeida, Ator em Aniki Bóbó
(45, 1, 33, 15), -- Humphrey Bogart, Ator em À bout de souffle
(46, 2, 35, 16), -- Vivien Leigh, Atriz em Cléo de 5 à 7
(47, 1, 27, 17), -- Joaquim de Almeida, Ator em Capitães de Abril
(48, 2, 30, 18), -- Léa Seydoux, Atriz em La Belle Époque
(49, 1, 38, 19), -- Javier Bardem, Ator em Pain and Glory
(50, 2, 39, 20), -- Audrey Tautou, Atriz em The Others
(51, 1, 40, 21), -- Daniel Brühl, Ator em The Lobster
(52, 2, 30, 22), -- Léa Seydoux, Atriz em Amélie
(53, 1, 37, 23), -- Wagner Moura, Ator em Elite Squad
(54, 1, 38, 24), -- Javier Bardem, Ator em Biutiful
(55, 1, 25, 25), -- Christoph Waltz, Ator em Inglourious Basterds
(56, 2, 16, 26), -- Jennifer Lawrence, Atriz em Frances Ha
(57, 2, 6, 27), -- Sally Hawkins, Atriz em The Shape of Water
(58, 2, 8, 28), -- Scarlett Johansson, Atriz em Roma
(59, 1, 14, 29), -- Frank Langella, Ator em Frost/Nixon
(60, 1, 27, 30); -- Matheus Nachtergaele, Ator em O Auto da Compadecida

INSERT INTO Bilheteira (id, filme_id, pais_exibicao, receita_bilheteira)
VALUES
(1, 1, 'USA', 400000000.00),
(2, 1, 'Canada', 50000000.00),
(3, 1, 'UK', 100000000.00),
(4, 1, 'Japan', 200000000.00),
(5, 1, 'Germany', 100000000.00),
(6, 1, 'France', 150000000.00),
(7, 1, 'China', 200000000.00),
(8, 2, 'USA', 300000000.00),
(9, 2, 'Canada', 50000000.00),
(10, 2, 'UK', 150000000.00),
(11, 2, 'Japan', 100000000.00),
(12, 2, 'Germany', 70000000.00),
(13, 2, 'France', 100000000.00),
(14, 2, 'China', 66000000.00),
(15, 3, 'USA', 600000000.00),
(16, 3, 'Canada', 100000000.00),
(17, 3, 'UK', 200000000.00),
(18, 3, 'Japan', 300000000.00),
(19, 3, 'Germany', 200000000.00),
(20, 3, 'France', 300000000.00),
(21, 3, 'China', 200000000.00),
(22, 4, 'USA', 400000000.00),
(23, 4, 'Canada', 60000000.00),
(24, 4, 'UK', 150000000.00),
(25, 4, 'Japan', 80000000.00),
(26, 4, 'Germany', 90000000.00),
(27, 4, 'France', 120000000.00),
(28, 4, 'China', 80000000.00),
(29, 5, 'USA', 800000000.00),
(30, 5, 'Canada', 100000000.00),
(31, 5, 'UK', 200000000.00),
(32, 5, 'Japan', 300000000.00),
(33, 5, 'Germany', 250000000.00),
(34, 5, 'France', 400000000.00),
(35, 5, 'China', 600000000.00),
(36, 6, 'USA', 300000000.00),
(37, 6, 'Canada', 50000000.00),
(38, 6, 'UK', 80000000.00),
(39, 6, 'Japan', 60000000.00),
(40, 6, 'Germany', 70000000.00),
(41, 6, 'France', 60000000.00),
(42, 6, 'China', 50000000.00),
(43, 7, 'USA', 150000000.00),
(44, 7, 'Canada', 20000000.00),
(45, 7, 'UK', 50000000.00),
(46, 7, 'Japan', 50000000.00),
(47, 7, 'Germany', 40000000.00),
(48, 7, 'France', 60000000.00),
(49, 7, 'China', 40000000.00),
(50, 8, 'USA', 250000000.00),
(51, 8, 'Canada', 50000000.00),
(52, 8, 'UK', 100000000.00),
(53, 8, 'Japan', 70000000.00),
(54, 8, 'Germany', 50000000.00),
(55, 8, 'France', 90000000.00),
(56, 8, 'China', 62000000.00),
(57, 9, 'USA', 150000000.00),
(58, 9, 'Canada', 20000000.00),
(59, 9, 'UK', 50000000.00),
(60, 9, 'Japan', 30000000.00),
(61, 9, 'Germany', 40000000.00),
(62, 9, 'France', 50000000.00),
(63, 9, 'China', 34000000.00),
(64, 10, 'USA', 200000000.00),
(65, 10, 'Canada', 30000000.00),
(66, 10, 'UK', 80000000.00),
(67, 10, 'Japan', 60000000.00),
(68, 10, 'Germany', 40000000.00),
(69, 10, 'France', 50000000.00),
(70, 10, 'China', 63000000.00),
(71, 11, 'USA', 32000000.00),
(72, 11, 'Canada', 5000000.00),
(73, 11, 'UK', 7000000.00),
(74, 11, 'Japan', 2000000.00),
(75, 11, 'Germany', 6000000.00),
(76, 12, 'Spain', 5000000.00),
(77, 12, 'France', 2000000.00),
(78, 12, 'Mexico', 1500000.00),
(79, 12, 'Argentina', 1000000.00),
(80, 12, 'Brazil', 800000.00),
(81, 13, 'Italy', 18000000.00),
(82, 13, 'France', 5000000.00),
(83, 13, 'Germany', 3000000.00),
(84, 13, 'Spain', 4000000.00),
(85, 13, 'UK', 2500000.00),
(86, 14, 'Portugal', 100000.00),
(87, 14, 'Spain', 50000.00),
(88, 14, 'Brazil', 20000.00),
(89, 15, 'France', 300000.00),
(90, 15, 'Belgium', 100000.00),
(91, 15, 'Switzerland', 80000.00),
(92, 15, 'Canada', 120000.00),
(93, 15, 'Japan', 90000.00),
(94, 16, 'France', 750000.00),
(95, 16, 'UK', 400000.00),
(96, 16, 'USA', 300000.00),
(97, 16, 'Canada', 200000.00),
(98, 16, 'Germany', 150000.00),
(99, 17, 'Portugal', 3000000.00),
(100, 17, 'Brazil', 1500000.00),
(101, 17, 'Spain', 800000.00),
(102, 17, 'France', 600000.00),
(103, 17, 'USA', 700000.00),
(104, 18, 'France', 12946347.00),
(105, 18, 'Belgium', 1000000.00),
(106, 18, 'Switzerland', 900000.00),
(107, 18, 'Canada', 2000000.00),
(108, 18, 'Japan', 1500000.00),
(109, 19, 'Spain', 17000000.00),
(110, 19, 'Argentina', 4000000.00),
(111, 19, 'Mexico', 6000000.00),
(112, 19, 'USA', 8000000.00),
(113, 19, 'UK', 3000000.00),
(114, 20, 'Spain', 97000000.00),
(115, 20, 'USA', 60000000.00),
(116, 20, 'Japan', 25000000.00),
(117, 20, 'UK', 20000000.00),
(118, 20, 'France', 15000000.00),
(119, 21, 'Ireland', 12000000.00),
(120, 21, 'UK', 6000000.00),
(121, 21, 'USA', 9000000.00),
(122, 21, 'Canada', 4000000.00),
(123, 21, 'Japan', 5000000.00),
(124, 22, 'France', 174200000.00),
(125, 22, 'Belgium', 20000000.00),
(126, 22, 'Switzerland', 18000000.00),
(127, 22, 'Canada', 25000000.00),
(128, 22, 'Japan', 22000000.00),
(129, 23, 'Brazil', 9000000.00),
(130, 23, 'Argentina', 3000000.00),
(131, 23, 'Mexico', 4000000.00),
(132, 23, 'Spain', 5000000.00),
(133, 23, 'USA', 7000000.00),
(134, 24, 'Mexico', 17000000.00),
(135, 24, 'Spain', 10000000.00),
(136, 24, 'Argentina', 5000000.00),
(137, 24, 'USA', 6000000.00),
(138, 24, 'Canada', 4000000.00),
(139, 25, 'USA', 200000000.00),
(140, 25, 'UK', 80000000.00),
(141, 25, 'Germany', 70000000.00),
(142, 25, 'France', 50000000.00),
(143, 25, 'Japan', 60000000.00),
(144, 26, 'USA', 11600000.00),
(145, 26, 'Canada', 3000000.00),
(146, 26, 'UK', 5000000.00),
(147, 26, 'Japan', 2000000.00),
(148, 26, 'France', 4000000.00),
(149, 27, 'USA', 195243716.00),
(150, 27, 'Canada', 50000000.00),
(151, 27, 'UK', 60000000.00),
(152, 27, 'Germany', 30000000.00),
(153, 27, 'France', 25000000.00),
(154, 28, 'Mexico', 5000000.00),
(155, 28, 'USA', 2000000.00),
(156, 28, 'Spain', 1500000.00),
(157, 28, 'Argentina', 1000000.00),
(158, 28, 'Brazil', 800000.00),
(159, 29, 'USA', 27393127.00),
(160, 29, 'UK', 12000000.00),
(161, 29, 'Germany', 9000000.00),
(162, 29, 'France', 8000000.00),
(163, 29, 'Japan', 7000000.00),
(164, 30, 'Brazil', 11000000.00),
(165, 30, 'Portugal', 3000000.00),
(166, 30, 'Spain', 2000000.00),
(167, 30, 'France', 1500000.00),
(168, 30, 'USA', 5000000.00);

INSERT INTO Merchandising (id, filme_id, merchandising)
VALUES
(1, 1, 63000000.00),
(2, 2, 160000000.00),
(3, 3, 200000000.00),
(4, 4, 185000000.00),
(5, 5, 237000000.00),
(6, 6, 149000000.00),
(7, 7, 63000000.00),
(8, 8, 165000000.00),
(9, 9, 150000000.00),
(10, 10, 135000000.00),
(11, 11, 806947.00),
(12, 12, 400000.00),
(13, 13, 800000.00),
(14, 14, 20000.00),
(15, 15, 50000.00),
(16, 16, 32000.00),
(17, 17, 1000000.00),
(18, 18, 9500000.00),
(19, 19, 10500000.00),
(20, 20, 17000000.00),
(21, 21, 4000000.00),
(22, 22, 10000000.00),
(23, 23, 4000000.00),
(24, 24, 5000000.00),
(25, 25, 70000000.00),
(26, 26, 3000000.00),
(27, 27, 19500000.00),
(28, 28, 15000000.00),
(29, 29, 25000000.00),
(30, 30, 700000.00);

INSERT INTO Custo_Producao (id, filme_id, custo_producao)
VALUES
(1, 1, 63000000.00), -- 'Jurassic Park'
(2, 2, 160000000.00), -- 'Inception'
(3, 3, 200000000.00), -- 'Titanic'
(4, 4, 185000000.00), -- 'The Dark Knight'
(5, 5, 237000000.00), -- 'Avatar'
(6, 6, 149000000.00), -- 'Wonder Woman'
(7, 7, 63000000.00), -- 'The Matrix'
(8, 8, 165000000.00), -- 'Interstellar'
(9, 9, 150000000.00), -- 'Mad Max: Fury Road'
(10, 10, 135000000.00), -- 'The Revenant'
(11, 11, 806947.00), -- 'Psycho'
(12, 12, 400000.00), -- 'Viridiana'
(13, 13, 800000.00), -- 'La Dolce Vita'
(14, 14, 20000.00), -- 'Aniki Bóbó'
(15, 15, 50000.00), -- 'À bout de souffle'
(16, 16, 32000.00), -- 'Cléo de 5 à 7'
(17, 17, 1000000.00), -- 'Capitães de Abril'
(18, 18, 9500000.00), -- 'La Belle Époque'
(19, 19, 10500000.00), -- 'Pain and Glory'
(20, 20, 17000000.00), -- 'The Others'
(21, 21, 4000000.00), -- 'The Lobster'
(22, 22, 10000000.00), -- 'Amélie'
(23, 23, 4000000.00), -- 'Elite Squad'
(24, 24, 5000000.00), -- 'Biutiful'
(25, 25, 70000000.00), -- 'Inglourious Basterds'
(26, 26, 3000000.00), -- 'Frances Ha'
(27, 27, 19500000.00), -- 'The Shape of Water'
(28, 28, 15000000.00), -- 'Roma'
(29, 29, 25000000.00), -- 'Frost/Nixon'
(30, 30, 700000.00); -- 'O Auto da Compadecida'