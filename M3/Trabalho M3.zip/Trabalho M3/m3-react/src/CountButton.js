import React, { useState } from 'react';
import { Button } from 'react-admin';
import { useDataProvider } from 'react-admin';

const CountButton = ({ resource }) => {
  const [count, setCount] = useState(null);
  const dataProvider = useDataProvider();
  

  const handleClick = async () => {
    const { total } = await dataProvider.getList(resource, {
      pagination: { page:1, perPage:1 },
      sort: { field: 'id', order: 'ASC' },
      filter: {},
    });
    setCount(total);
  };

  return (
    <div>
      <Button label={`Contar Entradas de ${resource}`} onClick={handleClick} />
      {count !== null && <p>Total de Entradas por Página: {count}</p>}
    </div>
  );
};

export default CountButton;