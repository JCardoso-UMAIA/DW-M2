import React, { useState } from 'react';
import { Button, useDataProvider } from 'react-admin';
import { TextField as MuiTextField } from '@mui/material';

const SearchFilmePaisButton = ({ resource }) => {
  const [filmeId, setFilmeId] = useState('');
  const [pais, setPais] = useState('');
  const [result, setResult] = useState(null);
  const [noResult, setNoResult] = useState(false);
  const dataProvider = useDataProvider();

  const handleClick = async () => {
    try {
      const response = await dataProvider.getList(resource, {
        filter: { filme_id: filmeId, pais: pais },
      });
      if (response.data.length > 0) {
        const filmeResponse = await dataProvider.getOne('filmes', { id: filmeId });
        setResult({
          filme_nome: filmeResponse.data.nome,
          pais: response.data[0].pais,
        });
        setNoResult(false);
      } else {
        setResult(null);
        setNoResult(true);
      }
    } catch (error) {
      setResult(null);
      setNoResult(true);
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <MuiTextField
        type="number"
        label="Introduza Filme ID"
        value={filmeId}
        onChange={(e) => setFilmeId(e.target.value)}
        variant="outlined"
        style={{ marginRight: '10px', padding: '5px' }}
      />
      <MuiTextField
        type="text"
        label="Introduza Pais"
        value={pais}
        onChange={(e) => setPais(e.target.value)}
        variant="outlined"
        style={{ marginRight: '10px', padding: '5px' }}
      />
      <Button label="Procurar" onClick={handleClick} />
      <p></p>
      {result && (
        <div style={{ marginTop: '20px' }}>
          <h3>Resultados:</h3>
          <p>Nome do Filme: {result.filme_nome}</p>
          <p>Pais: {result.pais}</p>
        </div>
      )}
      {noResult && (
        <div style={{ marginTop: '20px' }}>
          <h3>Sem resultados</h3>
        </div>
      )}
    </div>
  );
};

export default SearchFilmePaisButton;