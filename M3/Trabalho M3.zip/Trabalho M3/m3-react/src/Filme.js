import React from 'react';
import { List, Datagrid, TextField, NumberField, DeleteButton } from 'react-admin';
import CountButton from './CountButton';

export const FilmeList = (props) => (
  <List {...props}>
    <CountButton resource="filmes" />
    <p></p>
    <Datagrid>
      <NumberField source="id" />
      <TextField source="nome" />
      <TextField source="genero" />
      <TextField source="ano" />
      <TextField source="pais" />
      <DeleteButton />
    </Datagrid>
  </List>
);