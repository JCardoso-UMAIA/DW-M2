import React from 'react';
import { List, Datagrid, NumberField, TextField} from 'react-admin';
import CountButton from './CountButton';
import SearchFilmePaisButton from './SearchFilmePaisButton';

export const FilmePaisList = (props) => (
  <List {...props}>
    <CountButton resource="Filme_Pais" />
    <p></p>
    <SearchFilmePaisButton resource="Filme_Pais" />
    <Datagrid >
      <NumberField source="id" />
      <TextField source="pais" />
    </Datagrid>
  </List>
);
