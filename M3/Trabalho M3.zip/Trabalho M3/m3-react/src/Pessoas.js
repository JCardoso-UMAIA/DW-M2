import React from 'react';
import { List, Datagrid, TextField, DateField, SimpleForm, TextInput, Create, DateInput } from 'react-admin';
import CountButton from './CountButton';

export const PessoaList = (props) => (
    <List {...props}>
       <CountButton resource="pessoas" />
       <p></p>
       <Datagrid>
            <TextField source="id" />
            <TextField source="nome" label="Nome" />
            <TextField source="nome_artistico"label="Nome Artístico" />
            <TextField source="data_nascimento" label="Data de Nascimento" />
            <TextField source="local_nascimento" label="Local de Nascimento" />
            <DateField source="data_morte" label="D. Morte" />
            <TextField source="local_morte" label="Local de Morte"  />
        </Datagrid>
    </List>
);

export const PessoaCreate = (props) => (
  <Create {...props}>
    <SimpleForm>
      <TextInput source="nome"  label="Nome"/>
      <TextInput source="nome_artistico" label="Nome Artístico" />
      <DateInput source="data_nascimento" label="Data de Nascimento" />
      <TextInput source="local_nascimento" label="Local de Nascimento" />
      <TextInput source="data_morte" label="Data de Morte" />
      <TextInput source="local_morte" label="Local de Morte" />
    </SimpleForm>
  </Create>
);