import React, { useState } from 'react';
import { Button } from 'react-admin';
import { useDataProvider } from 'react-admin';

const SearchByIdButton = ({ resource, onSelectId }) => {
  const [id, setId] = useState('');
  const [result, setResult] = useState(null);
  const dataProvider = useDataProvider();

  const handleClick = async () => {
    try {
      const response = await dataProvider.getList(resource, {
        pagination: { page: 1, perPage: 1 },
        sort: { field: 'id', order: 'ASC' },
        filter: { filme_id: id },
      });
      setResult(response.data[0]); // Assuming response.data is an array
      onSelectId(id); // Pass the selected ID to the parent component
    } catch (error) {
      setResult(null);
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Introduza Filme ID"
        value={id}
        onChange={e => setId(e.target.value)}
        style={{ marginRight: '10px', padding: '5px' }}
      />
      <Button label="Procurar Filme ID" onClick={handleClick} />
      {result && (
        <div>
          <h3>Resultados:</h3>
          <p>Filme: {result.filme_id}</p>
          <p>Custo Produção: {result.custo_producao}</p>
        </div>
      )}
    </div>
  );
};

export default SearchByIdButton;