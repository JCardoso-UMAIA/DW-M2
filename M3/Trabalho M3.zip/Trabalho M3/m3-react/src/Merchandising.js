import React from 'react';
import { List, Datagrid, NumberField, ReferenceField, TextField, Edit, SimpleForm, TextInput, ReferenceInput, SelectInput } from 'react-admin';
import CountButton from './CountButton';

export const MerchandisingList = (props) => (
  <List {...props}>
    <CountButton resource="merchandisings" />
    <p></p>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <ReferenceField source="filme_id" reference="filmes">
        <TextField source="nome" />
      </ReferenceField>
      <NumberField source="merchandising" />
    </Datagrid>
  </List>
);

export const MerchandisingEdit = (props) => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="id" disabled />
      <ReferenceInput source="filme_id" reference="filmes">
        <SelectInput optionText="nome" />
      </ReferenceInput>
      <TextInput source="merchandising" />
    </SimpleForm>
  </Edit>
);