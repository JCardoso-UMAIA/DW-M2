import React from 'react';
import { List, Datagrid, TextField, Edit, SimpleForm, TextInput, Create, DeleteButton } from 'react-admin';
import CountButton from './CountButton';

export const FuncaoList = (props) => (
  <List {...props}>
    <CountButton resource="funcaos" label="Função" />
    <p></p>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <TextField source="nome" label="Nome" />
      <DeleteButton />
    </Datagrid>
  </List>
);

export const FuncaoEdit = (props) => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="id" disabled />
      <TextInput source="nome" label="Nome" />
    </SimpleForm>
  </Edit>
);

export const FuncaoCreate = (props) => (
  <Create {...props}>
    <SimpleForm>
      <TextInput source="nome" label="Nome"/>
    </SimpleForm>
  </Create>
);