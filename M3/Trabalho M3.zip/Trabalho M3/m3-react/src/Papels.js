import React from 'react';
import { List, Datagrid, TextField, ReferenceField, Edit, SimpleForm, TextInput, ReferenceInput, SelectInput } from 'react-admin';
import CountButton from './CountButton';

export const PapelsList = (props) => (
  <List {...props}>
    <CountButton resource="Custo_Producao" />
    <p></p>
    <Datagrid rowClick="edit">
      <TextField source="id" />
      <ReferenceField source="funcao_id" reference="funcaos">
        <TextField source="nome" />
      </ReferenceField>
      <ReferenceField source="pessoa_id" reference="pessoas">
        <TextField source="nome" />
      </ReferenceField>
      <ReferenceField source="filme_id" reference="filmes">
        <TextField source="nome" />
      </ReferenceField>
    </Datagrid>
  </List>
);

export const PapelsEdit = (props) => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="id" disabled />
      <ReferenceInput source="funcao_id" reference="funcaos">
        <SelectInput optionText="nome" />
      </ReferenceInput>
      <ReferenceInput source="pessoa_id" reference="pessoas">
        <SelectInput optionText="nome" />
      </ReferenceInput>
      <ReferenceInput source="filme_id" reference="filmes">
        <SelectInput optionText="nome" />
      </ReferenceInput>
    </SimpleForm>
  </Edit>
);