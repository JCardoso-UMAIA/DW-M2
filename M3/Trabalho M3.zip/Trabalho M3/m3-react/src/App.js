import React, { useState } from 'react';
import { Admin, AppBar, Layout, nanoDarkTheme, nanoLightTheme, radiantDarkTheme, radiantLightTheme, Resource } from 'react-admin';
import lb4Provider from 'react-admin-lb4';
import { PessoaList, PessoaCreate } from './Pessoas';
import { BilheteiraList } from './Bilheteira';
import { CustoProducaoList } from './CustoProducao';
import { FilmePaisList } from './FilmePais';
import { FilmeList } from './Filme';
import { MerchandisingList, MerchandisingEdit } from './Merchandising';
import { PapelsList, PapelsEdit } from './Papels';
import { FuncaoList, FuncaoEdit, FuncaoCreate } from './Funcao';
import { Button, Typography, Toolbar } from '@mui/material';
import { styled, createTheme, ThemeProvider } from '@mui/system';
import Dashboard from './Dashboard';

const dataProvider = lb4Provider('http://localhost:3000');

const themes = [nanoDarkTheme, nanoLightTheme, radiantDarkTheme, radiantLightTheme];

const customTheme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
  typography: {
    h6: {
      fontSize: '1.25rem',
      fontWeight: 500,
    },
  },
});

const CustomAppBar = ({ toggleTheme }) => {
  const CenteredAppBar = styled(AppBar)({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0 16px',
  });

  return (
    <CenteredAppBar position="static">
      <Toolbar>
        <Typography variant="h6" color="inherit" noWrap>
          Dashboard
        </Typography>
        <Button color="inherit" onClick={toggleTheme}>Toggle Theme</Button>
      </Toolbar>
    </CenteredAppBar>
  );
};

const CustomLayout = (props) => (
  <Layout {...props} appBar={(appBarProps) => <CustomAppBar {...appBarProps} toggleTheme={props.toggleTheme} />} />
);

const App = () => {
  const [currentTheme, setCurrentTheme] = useState(0);

  const toggleTheme = () => {
    setCurrentTheme((prevTheme) => (prevTheme + 1) % themes.length);
  };

  console.log('App rendered');

  return (
    <ThemeProvider theme={customTheme}>
      <Admin
        theme={themes[currentTheme]}
        dataProvider={dataProvider}
        layout={(layoutProps) => <CustomLayout {...layoutProps} toggleTheme={toggleTheme} />}
        dashboard={Dashboard}
      >
        <Resource name="Custo_Producao" list={CustoProducaoList} />
        <Resource name="Filme_Pais" list={FilmePaisList} />
        <Resource name="bilheteiras" list={BilheteiraList} />
        <Resource name="filmes" list={FilmeList} />
        <Resource name="merchandisings" list={MerchandisingList} edit={MerchandisingEdit} />
        <Resource name="papels" list={PapelsList} edit={PapelsEdit} />
        <Resource name="funcaos" list={FuncaoList} edit={FuncaoEdit} create={FuncaoCreate} />
        <Resource name="pessoas" list={PessoaList} create={PessoaCreate} />
      </Admin>
    </ThemeProvider>
  );
};

export default App;