import React from 'react';
import { List, Datagrid, TextField, NumberField } from 'react-admin';
import CountButton from './CountButton';
import SearchBilheteiraButton from './SearchBilheteiraButton';

export const BilheteiraList = (props) => (
  <List {...props}>
    <CountButton resource="bilheteiras" />
    <p></p>
    <SearchBilheteiraButton resource="bilheteiras" />
    <Datagrid >
      <NumberField source="id" />
      <TextField source="pais_exibicao" />
      <NumberField source="receita_bilheteira" />
    </Datagrid>
  </List>
);
