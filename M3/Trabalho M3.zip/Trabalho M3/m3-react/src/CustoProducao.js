import React, { useState, useEffect } from 'react';
import { List, Datagrid, NumberField, ReferenceField, TextField, useDataProvider } from 'react-admin';
import { Card, CardContent, Typography } from '@mui/material';
import CountButton from './CountButton';
import SearchByIdButton from './SearchByIdButton';

export const CustoProducaoList = (props) => {
  const [selectedId, setSelectedId] = useState(null);
  const [movieName, setMovieName] = useState('');
  const dataProvider = useDataProvider();

  useEffect(() => {
    const fetchMovieName = async () => {
      if (selectedId) {
        try {
          const { data } = await dataProvider.getOne('filmes', { id: selectedId });
          setMovieName(data.nome);
        } catch (error) {
          console.error('Error fetching movie name:', error);
          setMovieName('');
        }
      }
    };

    fetchMovieName();
  }, [selectedId, dataProvider]);

  return (
    <List {...props}>
      <CountButton resource="Custo_Producao" />
      <p></p>
      <SearchByIdButton resource="Custo_Producao" onSelectId={setSelectedId} />
      {selectedId && (
        <Card style={{ marginTop: '20px', marginBottom: '20px' }}>
          <CardContent>
            <Typography variant="h6">Filme Name: {movieName}</Typography>
          </CardContent>
        </Card>
      )}
      <Datagrid>
        <NumberField source="id" />
        <ReferenceField source="filme_id" reference="filmes">
          <TextField source="nome" />
        </ReferenceField>
        <NumberField source="custo_producao" />
      </Datagrid>
    </List>
  );
};