import React, { useEffect, useState } from 'react';
import { CardContent, Typography, Grid, Paper } from '@mui/material';
import { useDataProvider } from 'react-admin';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const dataProvider = useDataProvider();
  const [stats, setStats] = useState({
    pessoas: 0,
    bilheteiras: 0,
    custoProducao: 0,
    filmePais: 0,
    filmes: 0,
    merchandisings: 0,
    papels: 0,
    funcaos: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const pessoas = await dataProvider.getList('pessoas', { spagination: { page: 1, perPage: 1 } });
        const bilheteiras = await dataProvider.getList('bilheteiras', { pagination: { page: 1, perPage: 1 } });
        const custoProducao = await dataProvider.getList('Custo_Producao', { pagination: { page: 1, perPage: 1 } });
        const filmePais = await dataProvider.getList('Filme_Pais', { pagination: { page: 1, perPage: 1 } });
        const filmes = await dataProvider.getList('filmes', { pagination: { page: 1, perPage: 1 } });
        const merchandisings = await dataProvider.getList('merchandisings', { pagination: { page: 1, perPage: 1 } });
        const papels = await dataProvider.getList('papels', { pagination: { page: 1, perPage: 1 } });
        const funcaos = await dataProvider.getList('funcaos', { pagination: { page: 1, perPage: 1 } });

        setStats({
          pessoas: pessoas.total,
          bilheteiras: bilheteiras.total,
          custoProducao: custoProducao.total,
          filmePais: filmePais.total,
          filmes: filmes.total,
          merchandisings: merchandisings.total,
          papels: papels.total,
          funcaos: funcaos.total,
        });
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    };

    fetchStats();
  }, [dataProvider]);

  const data = [
    { name: 'Pessoas', value: stats.pessoas },
    { name: 'Bil.', value: stats.bilheteiras },
    { name: 'Produção', value: stats.custoProducao },
    { name: 'F.País', value: stats.filmePais },
    { name: 'Filmes', value: stats.filmes },
    { name: 'Merch.', value: stats.merchandisings },
    { name: 'Papeis', value: stats.papels },
    { name: 'Função', value: stats.funcaos },
  ];

  return (
    <div>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper>
            <CardContent>
              <Typography variant="h6">Estatísticas</Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper>
            <CardContent>
              <Typography variant="h6">Detalhes</Typography>
              <Typography variant="body1">Total Pessoas: {stats.pessoas}</Typography>
              <Typography variant="body1">Total Bilheteiras: {stats.bilheteiras}</Typography>
              <Typography variant="body1">Total Custo Produção: {stats.custoProducao}</Typography>
              <Typography variant="body1">Total Filme País: {stats.filmePais}</Typography>
              <Typography variant="body1">Total Filmes: {stats.filmes}</Typography>
              <Typography variant="body1">Total Merchandisings: {stats.merchandisings}</Typography>
              <Typography variant="body1">Total Papeis: {stats.papels}</Typography>
              <Typography variant="body1">Total Funçãos: {stats.funcaos}</Typography>
            </CardContent>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default Dashboard;