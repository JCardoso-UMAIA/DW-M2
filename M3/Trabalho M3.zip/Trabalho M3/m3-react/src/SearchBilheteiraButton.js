import React, { useState } from 'react';
import { Button, useDataProvider } from 'react-admin';
import { Card, CardContent, Typography, TextField as MuiTextField } from '@mui/material';

const SearchBilheteiraButton = ({ resource }) => {
  const [filmeId, setFilmeId] = useState('');
  const [result, setResult] = useState(null);
  const dataProvider = useDataProvider();

  const handleClick = async () => {
    try {
      const response = await dataProvider.getList(resource, {
        filter: { filme_id: filmeId },
      });
      setResult(response.data);
    } catch (error) {
      setResult(null);
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <MuiTextField
        type="number"
        label="Introduza Filme ID"
        value={filmeId}
        onChange={(e) => setFilmeId(e.target.value)}
        variant="outlined"
        style={{ marginRight: '10px', marginBottom: '10px' }}
      />
      <Button label="Procurar" onClick={handleClick} />
      <p></p>
      {result && (
        <div style={{ marginTop: '20px' }}>
          <Typography variant="h5">Resultados:</Typography>
          {result.map((bilheteira) => (
            <Card key={bilheteira.id} style={{ marginBottom: '10px' }}>
              <CardContent>
                <Typography variant="body1">País de Exibição: {bilheteira.pais_exibicao}</Typography>
                <Typography variant="body1">Receita de Bilheteira: {bilheteira.receita_bilheteira}</Typography>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default SearchBilheteiraButton;